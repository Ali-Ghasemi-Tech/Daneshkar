"""This a simple doc string for car module."""

from typing import NoReturn

class Car:
    """A simple attempt tp repr a car"""
    number = 0

    def __init__(self, brand, model, year):
        """Initializing attrs tp describe a car"""
        self.brand = brand
        self.model = model
        self.year = year
        self._odometer_reading = 0
        Car.number += 1

    def __len__(self):
        return 100000000

    def get_descriptive_name(self):
        """Return formated descriptive name."""

        return f"{self.year} {self.brand} {self.model}"
    
    def read_odometer(self):
        """Print a statement showing the cars mileage"""

        print(f"This car has {self._odometer_reading} miles on it.")


    def update_odometer(self, milage):
        if milage < 0:
            print("Only positive milage.")
            return

        self._odometer_reading = milage

    def increment_odometer(self, milage):
        if milage < 0:
            print("You cant roll back an odometer!")
            return
        
        self._odometer_reading += milage

    



# print(my_new_car.get_descriptive_name())
# my_new_car.read_odometer()

# my_new_car.update_odometer(10)
# my_new_car.read_odometer()
my_new_car = Car("audi", "a4", 2024)
your_car = Car("audi", "a8", 2024)

print(f"{your_car.number=}")

your_car.number = 100
print(f"{your_car.number=}")

your_car2 = Car("audi", "a8", 2024)

print(f"{my_new_car.number=}")
print(f"{Car.number=}")

Car.number = 100
print(f"{my_new_car.number=}")
print(f"{Car.number=}")

print(len(my_new_car))