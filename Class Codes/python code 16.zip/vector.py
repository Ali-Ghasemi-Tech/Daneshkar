import math

class Vector:

    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def __abs__(self):
        return math.hypot(self.x, self.y)
    
    def __bool__(self):
        return bool(abs(self))
    
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    
    def __str__(self):
        return f"{self.x}, {self.y}"

    def __repr__(self):
        return f"Vector({self.x!r}, {self.y!r})"


v = Vector(1,3)
print(v)

abs(v)
print(Vector(1,3))


print(bool(Vector(0, 1)))
    
# while Vector(2,1):
#     ...
print(str(Vector()))

print(Vector(2,1) + Vector(4,5))

# [] += []

print("0")
print(0)