a = 10

def test1():
    a = 23

    def test():
        # a = 20

        print(a)

    test()

test1()