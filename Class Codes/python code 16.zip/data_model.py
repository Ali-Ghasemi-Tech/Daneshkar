# print(len("kasdjfhkfha"))
# print(len([1,2,3,4]))
# print(len((1,2,3,4,5)))
# print(len({1:2, 3:4}))

# print(type("asaklsdhf"))


# print([1,2,3].__len__())



