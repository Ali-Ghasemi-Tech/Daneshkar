import car

def some_function(*args):
    ...


# class <class_name>:
#     ...

print()

class Dog:
    """akfhafkghds"""

    def __init__(self, name: str, age: int, allowed_food: list):
        print("....")
        self.name = name
        self.age = age
        self.allowed_food = allowed_food

    def sit(self):
        print(f"{self.name} is now sitting!")

    def woof(self):
        print("Woof")

    def eat(self, food):
        if food in self.allowed_food:
            print(f"{self.name} is now eatting {food}")

        else:
            print("*****!@##25")
            for _ in range(3):
                self.woof()


my_dog = Dog("Willie", 3, allowed_food=["meat"])
print("*********")
my_dog.sit()


your_dog = Dog("Lucy", 5, allowed_food=["meat"])
print("*********")
your_dog.sit()
your_dog.eat("grass")
your_dog.eat("meat")
